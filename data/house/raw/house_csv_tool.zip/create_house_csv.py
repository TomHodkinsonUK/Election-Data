import csv
import json
from pathlib import Path


# ------------------------------------------------------
# INPUT / OUTPUT
# ------------------------------------------------------

INPUT_DIR = Path("data/house/cleaned")
OUTPUT_DIR = Path("data/house/csv")

YEARS = [
    1960,
    1962,
    1964,
    1966,
    1968,
    1970,
    1972
]


# ------------------------------------------------------
# CONVERT ONE JSON FILE TO LONG CSV
# ------------------------------------------------------

def create_csv(year):

    input_file = INPUT_DIR / f"{year}.json"
    output_file = OUTPUT_DIR / f"{year}.csv"

    if not input_file.exists():
        print(
            f"{year}: file not found: {input_file}"
        )
        return

    with input_file.open(
        encoding="utf-8"
    ) as file:

        data = json.load(file)

    rows = []

    for district in data["counties"]:

        state = district["a"]
        district_name = district["n"]
        geoid = district["j"]
        total_votes = district["tv"]

        # The cleaned JSON uses -1 to mean:
        # "votes were not tabulated / not reported".
        votes_reported = (
            district.get("votes_reported", True)
            and total_votes != -1
        )

        district_unopposed = (
            district.get("unopposed", False)
        )

        for result in district["v"]:

            party = result["p"]
            votes = result["v"]
            percentage = result["perc"]

            party_unopposed = (
                result.get("unopposed", False)
            )

            party_votes_reported = (
                result.get(
                    "votes_reported",
                    votes != -1
                )
                and votes != -1
            )

            # --------------------------------------------------
            # HANDLE UNOPPOSED / UNREPORTED RACES
            #
            # We do NOT invent a vote total.
            # The CSV uses a blank value for votes and
            # total_votes when the source did not report them.
            #
            # The percentage remains 100% for the unopposed
            # winner, as recorded in the cleaned JSON.
            # --------------------------------------------------

            if not party_votes_reported:

                csv_votes = ""

                csv_total_votes = ""

            else:

                csv_votes = votes
                csv_total_votes = total_votes

            rows.append({

                "state": state,

                "district": district_name,

                "geoid": geoid,

                "total_votes": csv_total_votes,

                "party": party,

                "votes": csv_votes,

                "percentage": percentage * 100,

                "votes_reported": party_votes_reported,

                "unopposed": party_unopposed
            })

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    with output_file.open(
        "w",
        newline="",
        encoding="utf-8"
    ) as file:

        writer = csv.DictWriter(
            file,
            fieldnames=[
                "state",
                "district",
                "geoid",
                "total_votes",
                "party",
                "votes",
                "percentage",
                "votes_reported",
                "unopposed"
            ]
        )

        writer.writeheader()
        writer.writerows(rows)

    print(
        f"{year}: wrote {output_file} "
        f"({len(rows)} rows)"
    )


# ------------------------------------------------------
# CREATE ALL HOUSE CSVs
# ------------------------------------------------------

def main():

    print("Creating House election CSVs")
    print("--------------------------------")

    for year in YEARS:
        create_csv(year)


if __name__ == "__main__":
    main()
