# House JSON -> CSV converter

This converter is designed for the cleaned House election JSON files.

Expected input:

data/house/cleaned/1960.json
data/house/cleaned/1962.json
data/house/cleaned/1964.json
data/house/cleaned/1966.json
data/house/cleaned/1968.json
data/house/cleaned/1970.json
data/house/cleaned/1972.json

Output:

data/house/csv/1960.csv
...
data/house/csv/1972.csv

CSV columns:

state,district,geoid,total_votes,party,votes,percentage,votes_reported,unopposed

Important:
- Normal numerical results keep their reported vote totals.
- Unopposed/unreported results from the cleaned JSON use blank `total_votes` and blank `votes`.
- Their percentage remains 100% for the unopposed winner.
- `votes_reported=False` explicitly identifies the missing numerical tally.
- No invented vote totals are created.

Run from the repository root:

python analysis/create_house_csv.py

Put the script in the repository's `analysis/` directory.
